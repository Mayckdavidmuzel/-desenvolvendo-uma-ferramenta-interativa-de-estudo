criaCartao(
    'Felicidades',
    'O que precisa para ser feliz?',
    ' Fazer o que gosta!!!'
)

criaCartao(
    'Informática',
    'Qual o melhor canal para aprender informática',
    '@rasinformática'
)

criaCartao(
    'Qual é a melhor turma do CERB',
    'A que mais se dedica as aulas do Prof. Rafael?',
    'Estou em dúvida'
)

criaCartao(
    'Ganhando o Mundo',
    'Quem participou do Programa Ganhado o mundo em 2024?',
    'Eloisa Amorim dos Santos 👏👏👏'
)
